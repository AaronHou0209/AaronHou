function Book({ book }) {
  return (
    <p>
      Book:{book.title}, author: {book.author}
    </p>
  );
}

export default Book;
