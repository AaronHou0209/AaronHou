import "./App.css";
import BookList from "./component /BookList";
import Header from "./component /Header";
function App() {
  const books = [
    { title: "Java Programming", author: "Ivor Horton" },
    { title: "HTML & CSS", author: "Tim Berner’s Lee" },
    { title: "React JS", author: "A.Kurdi" },
    { title: "Angular JS", author: "R. Lafore II" },
  ];
  return (
    <div>
      <Header title="BooKList Website" />
      <BookList books={books} />
    </div>
  );
}

export default App;
